# pandas_homework
Sunday, 13th November 2022

This repository contains files with basic guidance on how to use pandas 
