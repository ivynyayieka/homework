# My Simple Website

This repository contains code for a simple website.

This repo is to help you learn about **Git** and **GitHub**.
