# cleaning_data_pandas
Pandas cleaning data project
This project contains guidance on cleaning data in pandas
